﻿using Abp.Authorization;
using blog-abp.Authorization.Roles;
using blog-abp.MultiTenancy;
using blog-abp.Users;

namespace blog-abp.Authorization
{
    public class PermissionChecker : PermissionChecker<Tenant, Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
