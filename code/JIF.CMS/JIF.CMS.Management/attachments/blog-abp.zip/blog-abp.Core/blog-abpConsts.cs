﻿namespace blog-abp
{
    public class blog-abpConsts
    {
        public const string LocalizationSourceName = "blog-abp";
    }
}