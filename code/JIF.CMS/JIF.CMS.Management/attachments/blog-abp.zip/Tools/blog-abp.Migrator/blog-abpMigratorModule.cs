using System.Data.Entity;
using System.Reflection;
using Abp.Modules;
using blog-abp.EntityFramework;

namespace blog-abp.Migrator
{
    [DependsOn(typeof(blog-abpDataModule))]
    public class blog-abpMigratorModule : AbpModule
    {
        public override void PreInitialize()
        {
            Database.SetInitializer<blog-abpDbContext>(null);

            Configuration.BackgroundJobs.IsJobExecutionEnabled = false;
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
        }
    }
}