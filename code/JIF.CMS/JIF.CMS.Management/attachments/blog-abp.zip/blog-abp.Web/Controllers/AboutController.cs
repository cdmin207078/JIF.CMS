﻿using System.Web.Mvc;

namespace blog-abp.Web.Controllers
{
    public class AboutController : blog-abpControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}