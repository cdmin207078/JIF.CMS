﻿using System.Web.Mvc;
using Abp.Web.Mvc.Authorization;

namespace blog-abp.Web.Controllers
{
    [AbpMvcAuthorize]
    public class HomeController : blog-abpControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}