﻿using Abp.Web.Mvc.Views;

namespace blog-abp.Web.Views
{
    public abstract class blog-abpWebViewPageBase : blog-abpWebViewPageBase<dynamic>
    {

    }

    public abstract class blog-abpWebViewPageBase<TModel> : AbpWebViewPage<TModel>
    {
        protected blog-abpWebViewPageBase()
        {
            LocalizationSourceName = blog-abpConsts.LocalizationSourceName;
        }
    }
}